// main.js

// =============================================================================
// Module Imports
// =============================================================================
// Import Electron modules needed to control the application life cycle and create windows.
const { app, BrowserWindow, ipcMain } = require('electron');

// Import Node core modules to handle file system operations, path manipulations, and raw TCP connections.
const fs = require('fs');
const path = require('path');
const net = require('net'); // Used for creating raw TCP connections

// Import node-fetch directly from its index file.
// This explicit import helps resolve module issues when the app is packaged.
const fetch = require('node-fetch/lib/index.js');

// =============================================================================
// Global Variables and Settings File Path
// =============================================================================

// 'mainWindow' will store our main application window.
let mainWindow;

// Construct the full path to the settings file (settings.txt) using the current directory.
const settingsFile = path.join(__dirname, 'settings.txt');

// Log to the console that the Electron app is starting.
console.log("🔍 Electron App Starting...");

// =============================================================================
// Application Configuration
// =============================================================================

// Disable GPU acceleration to avoid potential crashes or graphical issues.
app.disableHardwareAcceleration();

// =============================================================================
// Function: readSettings
// =============================================================================
/**
 * Reads application settings from a local text file (settings.txt).
 *
 * If the file exists, it reads the file, splits each line at the '=' character,
 * and creates a settings object with key/value pairs. If the file does not exist,
 * it returns a default settings object with an IP_ADDRESS.
 *
 * @returns {Object} An object containing the application settings.
 */
function readSettings() {
  console.log("📂 Reading settings file...");
  // Check if the settings file exists.
  if (fs.existsSync(settingsFile)) {
    // Read the file content as a UTF-8 string.
    const content = fs.readFileSync(settingsFile, 'utf-8');
    console.log("✅ Settings file found.");

    // Initialize an empty object to store settings.
    const settings = {};

    // Split the file into lines and process each one.
    content.split(/\r?\n/).forEach(line => {
      // Each line should be in "key=value" format.
      const [key, value] = line.split('=');
      if (key && value) {
        // Trim whitespace and add the key/value pair to the settings object.
        settings[key.trim()] = value.trim();
      }
    });

    console.log("🔹 Loaded settings:", settings);
    return settings;
  }
  // If the file doesn't exist, log a warning and return default settings.
  console.log("⚠️ No settings file found, using defaults.");
  return { IP_ADDRESS: '192.168.1.100' };
}

// =============================================================================
// Creating the Main Application Window
// =============================================================================

/**
 * This block waits for Electron to be ready, then creates the main browser window.
 * It sets the window dimensions and specifies a preload script for secure IPC (Inter-Process Communication).
 */
app.whenReady().then(() => {
  console.log("🚀 Creating Electron Window...");

  // Create the main application window with specified dimensions.
  mainWindow = new BrowserWindow({
    width: 1280,   // Set the window width (e.g., suitable for Panasonic Toughbook screens).
    height: 800,   // Set the window height.
    webPreferences: {
      // Preload script allows controlled access to Node.js APIs from the renderer process.
      preload: path.join(__dirname, 'preload.js'),
      // Enable context isolation for security reasons.
      contextIsolation: true
    }
  });

  // Load the HTML file that serves as the UI.
  mainWindow.loadFile('index.html');

  // Once the UI has finished loading, send the saved settings to the renderer process.
  mainWindow.webContents.once('did-finish-load', () => {
    console.log("✅ UI Loaded - Sending settings to renderer...");
    const settings = readSettings(); // Read settings from file.
    mainWindow.webContents.send('load-settings', settings); // Send settings to renderer.
  });
});

// =============================================================================
// IPC (Inter-Process Communication) Handlers
// =============================================================================

/**
 * IPC Handler: update-settings
 * Listens for an 'update-settings' message from the renderer process.
 * When received, it writes the new settings to the settings file and responds back with a log message.
 */
ipcMain.on('update-settings', (event, settings) => {
  console.log("🔄 Received new settings from UI:", settings);
  
  // Convert the settings object into a string in "key=value" format.
  const content = Object.entries(settings)
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');
  
  // Write the updated settings to the settings file.
  fs.writeFileSync(settingsFile, content, 'utf-8');
  
  // Send a reply back to the renderer process to log that settings were updated.
  event.reply('log-message', `Settings updated: ${JSON.stringify(settings)}`);
});

/**
 * IPC Handler: request-settings
 * Listens for a 'request-settings' message from the renderer process.
 * When received, it reads the settings file and sends the settings back.
 */
ipcMain.on('request-settings', (event) => {
  const settings = readSettings(); // Get current settings.
  event.reply('load-settings', settings); // Send settings to renderer.
});

/**
 * IPC Handler: send-command
 * Listens for a 'send-command' message from the renderer process.
 * Based on the connection type specified (TCP or HTTP), it sends the command accordingly.
 */
ipcMain.on('send-command', (event, commandObj) => {
  console.log("DEBUG: Main Process Received Command:", commandObj);

  // If the connection type is TCP, use a raw TCP socket.
  if (commandObj.connection === 'tcp') {
    sendTCPCommand(commandObj.ip, commandObj.port, commandObj.type, event, (err, response) => {
      if (err) {
        console.error("DEBUG: Error sending TCP command:", err);
        event.reply('log-message', `TCP Error: ${err.message}`);
      } else {
        console.log("DEBUG: TCP command response:", response);
        event.reply('log-message', `TCP Response: ${response}`);
      }
    });
  } else {
    // For HTTP connections, log the command and use node-fetch to send an HTTP POST request.
    event.reply('log-message', "HTTP Sent: " + commandObj.type);
    sendHTTPCommand(commandObj.url, commandObj.type)
      .then(responseText => {
        console.log("DEBUG: HTTP command response:", responseText);
        event.reply('log-message', `HTTP Response: ${responseText}`);
      })
      .catch(error => {
        console.error("DEBUG: HTTP command error:", error);
        event.reply('log-message', `HTTP Error: ${error.message}`);
      });
  }
});

// =============================================================================
// Function: sendTCPCommand
// =============================================================================
/**
 * Opens a raw TCP connection to a specified IP address and port, sends a command,
 * and then listens for a response. Once data is received, the callback function
 * is called with the response.
 *
 * @param {string} ip - The target IP address.
 * @param {number} port - The target port number.
 * @param {string} command - The command string to send.
 * @param {object} event - The IPC event object for sending replies.
 * @param {function} callback - A callback function to handle the response or error.
 */
function sendTCPCommand(ip, port, command, event, callback) {
  console.log(`DEBUG: Attempting TCP connection to ${ip}:${port}`);

  // Create a new TCP socket.
  const client = new net.Socket();

  // Connect to the specified IP and port.
  client.connect(port, ip, () => {
    console.log("DEBUG: TCP connection established");
    // Write the command to the socket.
    client.write(command, () => {
      console.log("DEBUG: TCP Sent:", command);
      // Notify the renderer that the command was sent.
      event.reply('log-message', "TCP Sent: " + command);
    });
  });

  // Listen for data coming back from the server.
  client.on('data', (data) => {
    const response = data.toString(); // Convert the received data to a string.
    console.log("DEBUG: Received TCP data:", response);
    // If a callback was provided, pass the response.
    if (callback) {
      callback(null, response);
    }
    client.destroy(); // Close the connection after receiving data.
  });

  // Handle any errors that occur during the TCP connection.
  client.on('error', (err) => {
    console.error("DEBUG: TCP connection error:", err);
    if (callback) {
      callback(err);
    }
  });
}

// =============================================================================
// Function: sendHTTPCommand
// =============================================================================
/**
 * Sends an HTTP POST request to a specified URL with the provided command as the payload.
 *
 * This function uses node-fetch to send the request, logs the HTTP status, and then
 * returns the response as text.
 *
 * @param {string} url - The URL to send the HTTP request to.
 * @param {string} command - The command string to send in the request body.
 * @returns {Promise<string>} A promise that resolves to the text of the HTTP response.
 */
function sendHTTPCommand(url, command) {
  console.log(`DEBUG: Sending HTTP Request to: ${url}`);
  console.log(`DEBUG: HTTP Payload: ${command}`);
  
  // Use node-fetch to send an HTTP POST request.
  return fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' }, // Set content type to plain text.
    body: command // The payload is the command.
  })
  .then(response => {
    console.log("DEBUG: HTTP Response Status:", response.status);
    return response.text(); // Return the response text.
  });
}
