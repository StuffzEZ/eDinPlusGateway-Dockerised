// renderer.js

// =============================================================================
// Helper Functions
// =============================================================================

/**
 * Pads a number with leading zeros so that the resulting string has at least
 * the specified number of characters.
 */
function pad(num, size) {
  return num.toString().padStart(size, '0');
}

/**
 * Constructs a user prefix string using the username and password.
 */
function getUserPrefix() {
  const username = document.getElementById('username')
    ? document.getElementById('username').value
    : (localStorage.getItem("USERNAME") || "Configurator");

  const password = document.getElementById('password')
    ? document.getElementById('password').value
    : (localStorage.getItem("PASSWORD") || "mode-x");

  console.log("DEBUG: getUserPrefix returns:", `$User,${username},${password};`);
  return `$User,${username},${password};`;
}

// =============================================================================
// Global Variables for DALI Operations
// =============================================================================

let daliBroadcastInterval = null;
let daliBSTInterval = null;
let daliBSTState = true;
let daliFittingEMIdentifyInterval = null;
let flashDaliFittingInterval = null;
let flashDaliFittingState = true;

// =============================================================================
// Area Section Functions
// =============================================================================

/**
 * Sends the ?areanames; command to load area names.
 */
function loadAreaNames() {
  // Clear any existing area tiles.
  createAreaTiles([]);
  // Request area names.
  sendCommand('?areanames;');
}

/**
 * Parses a response containing !AREANAME lines and returns an array of objects.
 * Each object contains:
 *   - num: the area number (e.g., "00001")
 *   - name: the area name (only if non-empty)
 */
function parseAreaResponse(responseText) {
  const lines = responseText.split(/[\r\n]+/);
  const areas = [];
  lines.forEach(line => {
    line = line.trim();
    if (line.startsWith('!AREANAME,')) {
      if (line.endsWith(';')) {
        line = line.slice(0, -1);
      }
      const parts = line.split(',');
      if (parts.length >= 5) {
        const areaNum = parts[1].trim();
        const areaName = parts[4].trim();
        if (areaName !== '') {
          areas.push({ num: areaNum, name: areaName });
        }
      }
    }
  });
  return areas;
}

/**
 * Creates area tiles (buttons) in the left container.
 * Each tile stores the area number so that when clicked, it sends the ?SCNNAMES command.
 */
function createAreaTiles(areas) {
  const container = document.getElementById('tileContainer');
  if (!container) {
    console.error('Tile container not found!');
    return;
  }
  container.innerHTML = ''; // Clear existing content
  areas.forEach(area => {
    const btn = document.createElement('button');
    btn.classList.add('tile-button');
    btn.textContent = area.name;
    btn.addEventListener('click', () => {
      console.log('Tile clicked:', area.name, 'with area number:', area.num);
      // Convert area number to an integer (to remove any leading zeros)
      const areaNumInt = parseInt(area.num, 10);
      // Send the scene names command for this area.
      sendCommand(`?SCNNAMES,${areaNumInt};`);
    });
    container.appendChild(btn);
  });
}

/**
 * Parses a response containing !SCNNAME lines and returns an array of objects.
 * Each object contains:
 *   - num: the scene number (e.g., "00005")
 *   - name: the scene name (e.g., "5" or "Off")
 */
function parseSceneResponse(responseText) {
  const lines = responseText.split(/[\r\n]+/);
  const scenes = [];
  lines.forEach(line => {
    line = line.trim();
    if (line.startsWith('!SCNNAME,')) {
      if (line.endsWith(';')) {
        line = line.slice(0, -1);
      }
      const parts = line.split(',');
      if (parts.length >= 5) {
        const scnNum = parts[1].trim();
        const scnName = parts[4].trim();
        if (scnName !== '') {
          scenes.push({ num: scnNum, name: scnName });
        }
      }
    }
  });
  return scenes;
}

/**
 * Creates scene buttons in the right container.
 * When a scene button is pressed, it sends out the scene trigger command.
 */
function createSceneButtons(scenes) {
  const container = document.querySelector('.areawindowright');
  if (!container) {
    console.error('Scene container not found!');
    return;
  }
  container.innerHTML = ''; // Clear existing content
  scenes.forEach(scene => {
    const btn = document.createElement('button');
    btn.classList.add('scene-button');
    btn.textContent = scene.name;
    btn.addEventListener('click', () => {
      console.log('Scene button clicked:', scene.name, 'with scene number:', scene.num);
      // Send the scene trigger command
      sendCommand(`$SCNRECALL,${scene.num};`);
    });
    container.appendChild(btn);
  });
}

// =============================================================================
// Settings Functions
// =============================================================================

function saveSettings() {
  const newSettings = {
    IP_ADDRESS: document.getElementById('ipAddress')
      ? document.getElementById('ipAddress').value
      : localStorage.getItem("IP_ADDRESS") || "192.168.1.100",
    USERNAME: document.getElementById('username')
      ? document.getElementById('username').value
      : localStorage.getItem("USERNAME") || "Configurator",
    PASSWORD: document.getElementById('password')
      ? document.getElementById('password').value
      : localStorage.getItem("PASSWORD") || "mode-x"
  };

  console.log("DEBUG: Saving Settings:", newSettings);
  window.electronAPI.updateSettings(newSettings);
  localStorage.setItem("IP_ADDRESS", newSettings.IP_ADDRESS);
  localStorage.setItem("USERNAME", newSettings.USERNAME);
  localStorage.setItem("PASSWORD", newSettings.PASSWORD);
}

function testConnection() {
  const prefix = getUserPrefix();
  const command = `${prefix}?VERSION;`;
  console.log("DEBUG: Sending Test Connection Command:", command);
  sendRawCommand(command);
}

function sendTestCommand() {
  const commandInput = document.getElementById('testCommand');
  if (!commandInput) {
    console.error("DEBUG: Test command input field not found.");
    return;
  }

  const command = commandInput.value.trim();
  if (!command) {
    logMessage("⚠️ No command entered.", "log-warning");
    return;
  }

  console.log(`DEBUG: Sending Test Command: ${command}`);
  sendCommand(command);
}

// =============================================================================
// Command Functions
// =============================================================================

function sendCommand(type) {
  try {
    const ip = localStorage.getItem("IP_ADDRESS") || "192.168.1.100";
    const connectionType = document.getElementById('connectionType')
      ? document.getElementById('connectionType').value
      : "http";
    const port = (connectionType === "tcp") ? 26 : 80;
    let url;

    if (connectionType === "tcp") {
      url = `${ip}:${port}`;
    } else {
      url = `http://${ip}:${port}/gateway?`;
    }
    
    const username = document.getElementById('username') ? document.getElementById('username').value : "";
    const password = document.getElementById('password') ? document.getElementById('password').value : "";
    let fullCommand = type;

    if (username && password) {
      fullCommand = `$User,${username},${password};` + type;
    }

    console.log("DEBUG: UI Sending Command:", fullCommand);
    console.log(`DEBUG: Connection Type: ${connectionType}, IP: ${ip}, Port: ${port}`);
    console.log(`DEBUG: URL: ${url}`);

    if (window.electronAPI) {
      window.electronAPI.sendCommand({ type: fullCommand, connection: connectionType, ip, port, url });
      console.log("DEBUG: Command sent via ipcRenderer.");
    } else {
      console.error("DEBUG: ipcRenderer (electronAPI) is NOT available! Check preload.js.");
    }
  } catch (error) {
    console.error("DEBUG: Error in sendCommand:", error);
  }
}

function sendKeypadCommand(buttonNumber) {
  const addr = document.getElementById('addr') ? document.getElementById('addr').value : "";
  const devcode = document.getElementById('devcode') ? document.getElementById('devcode').value : "";
  const state = document.getElementById('state') ? document.getElementById('state').value : "";
  const command = `$BTNSTATE,${addr},${devcode},${buttonNumber},${state};`;
  console.log("DEBUG: Sending Keypad Command:", command);
  sendCommand(command);
}

function sendChannelFadeCommand() {
  const addr = document.getElementById('channel-addr') ? document.getElementById('channel-addr').value : "";
  const devcode = document.getElementById('channel-devcode') ? document.getElementById('channel-devcode').value : "";
  const chanNum = document.getElementById('channel-num') ? document.getElementById('channel-num').value : "";
  const level = document.getElementById('channel-level') ? document.getElementById('channel-level').value : "";
  const fadetime = document.getElementById('channel-fadetime') ? document.getElementById('channel-fadetime').value : "";
  const command = `$CHANFADE,${addr},${devcode},${chanNum},${level},${fadetime};`;
  console.log("DEBUG: Sending Channel Fade Command:", command);
  sendCommand(command);
}

function sendRawCommand(message) {
  try {
    const ip = localStorage.getItem("IP_ADDRESS") || "192.168.1.100";
    const connectionType = document.getElementById('connectionType')
      ? document.getElementById('connectionType').value
      : "http";
    const port = (connectionType === "tcp") ? 26 : 80;
    let url;

    if (connectionType === "tcp") {
      url = `${ip}:${port}`;
    } else {
      url = `http://${ip}:${port}/gateway?`;
    }

    console.log("DEBUG: UI Sending Raw Command:", message);
    console.log(`DEBUG: URL for raw command: ${url}`);

    if (window.electronAPI) {
      window.electronAPI.sendCommand({ type: message, connection: connectionType, ip, port, url });
      console.log("DEBUG: Raw command sent via ipcRenderer.");
    } else {
      console.error("DEBUG: ipcRenderer (electronAPI) is NOT available! Check preload.js.");
    }
  } catch (error) {
    console.error("DEBUG: Error in sendRawCommand:", error);
  }
}

// =============================================================================
// Event Handlers for Receiving Messages from the Main Process
// =============================================================================

window.electronAPI.onLogMessage((message) => {
  console.log("DEBUG: UI Log Message Received:", message);
  logMessage(message, "log-response");

  // If the message contains area name data, parse and update area tiles.
  if (message.includes("!AREANAME,")) {
    const areas = parseAreaResponse(message);
    createAreaTiles(areas);
  }
  // If the message contains scene name data, parse and update scene buttons.
  else if (message.includes("!SCNNAME,")) {
    const scenes = parseSceneResponse(message);
    createSceneButtons(scenes);
  }

  if (message.includes("!VERSION")) {
    logMessage("Connection Successful", "log-success");
  }
});

window.electronAPI.onLoadSettings((settings) => {
  console.log("DEBUG: Loaded settings:", settings);
  if (document.getElementById('ipAddress') && settings.IP_ADDRESS) {
    document.getElementById('ipAddress').value = settings.IP_ADDRESS;
  }
  if (document.getElementById('username') && settings.USERNAME) {
    document.getElementById('username').value = settings.USERNAME;
  }
  if (document.getElementById('password') && settings.PASSWORD) {
    document.getElementById('password').value = settings.PASSWORD;
  }
});

// =============================================================================
// UI Utility Functions
// =============================================================================

function logMessage(message, type = "log-message") {
  const logElement = document.getElementById('log');
  if (!logElement) {
    console.error("DEBUG: Log container not found!");
    return;
  }

  const newMessage = document.createElement("div");
  newMessage.classList.add(type);
  newMessage.textContent = message;
  logElement.appendChild(newMessage);

  const logContainer = document.getElementById('log-container');
  logContainer.scrollTop = logContainer.scrollHeight;
}

function clearLog() {
  console.log("DEBUG: Clearing Log...");
  if (document.getElementById('log')) {
    document.getElementById('log').textContent = "";
  }
}

// =============================================================================
// Window onload Event
// =============================================================================

window.onload = () => {
  console.log("DEBUG: UI Loaded - Fetching Settings...");
  window.electronAPI.requestSettings();

  const channelLevel = document.getElementById('channel-level');
  const display = document.getElementById('channel-level-display');
  if (channelLevel && display) {
    channelLevel.addEventListener('input', function () {
      display.textContent = channelLevel.value;
    });
  }
};

// =============================================================================
// DALI Command Functions (unchanged)
// =============================================================================

function toggleDaliBroadcast() {
  if (daliBroadcastInterval === null) {
    const ubc = document.getElementById('dali-ubc') ? document.getElementById('dali-ubc').value : "001";
    const prefix = getUserPrefix();
    const message = `${prefix}$XDALIAPPX2,001,017,BST,240,${ubc};`;
    console.log("DEBUG: Starting DALI EM Identify Broadcast with message:", message);
    sendRawCommand(message);
    daliBroadcastInterval = setInterval(() => {
      sendRawCommand(message);
    }, 10000);
    const btn = document.getElementById('dali-broadcast-btn');
    if (btn) { btn.textContent = "Stop EM Identify Broadcast"; }
  } else {
    console.log("DEBUG: Stopping DALI EM Identify Broadcast.");
    clearInterval(daliBroadcastInterval);
    daliBroadcastInterval = null;
    const btn = document.getElementById('dali-broadcast-btn');
    if (btn) { btn.textContent = "Start EM Identify Broadcast"; }
  }
}

function toggleDaliBST() {
  const ubc = document.getElementById('dali-ubc') ? document.getElementById('dali-ubc').value : "001";
  const prefix = getUserPrefix();
  const commandA = `${prefix}$xdali,${ubc},017,BST,5;`;
  const commandB = `${prefix}$xdali,${ubc},017,BST,6;`;

  if (daliBSTInterval === null) {
    console.log("DEBUG: Starting DALI BST Broadcast. Command A:", commandA);
    sendRawCommand(commandA);
    daliBSTState = true;

    daliBSTInterval = setInterval(() => {
      const cmdToSend = daliBSTState ? commandB : commandA;
      console.log("DEBUG: Sending alternating DALI BST command:", cmdToSend);
      sendRawCommand(cmdToSend);
      daliBSTState = !daliBSTState;
    }, 5000);

    const btn = document.getElementById('dali-bst-btn');
    if (btn) { btn.textContent = "Stop Dali BST"; }
  } else {
    console.log("DEBUG: Stopping DALI BST Broadcast.");
    clearInterval(daliBSTInterval);
    daliBSTInterval = null;
    sendRawCommand(commandA);
    const btn = document.getElementById('dali-bst-btn');
    if (btn) { btn.textContent = "Start Dali BST"; }
  }
}

function sendDaliOn() {
  const ubc = document.getElementById('dali-ubc') ? document.getElementById('dali-ubc').value : "001";
  const prefix = getUserPrefix();
  const command = `${prefix}$xdali,${ubc},017,BST,5;`;
  console.log("DEBUG: Sending Dali On Command:", command);
  sendRawCommand(command);
}

function sendDaliOff() {
  const ubc = document.getElementById('dali-ubc') ? document.getElementById('dali-ubc').value : "001";
  const prefix = getUserPrefix();
  const command1 = `${prefix}$xdali,${ubc},017,BST,6;`;
  const command2 = `${prefix}$xdali,${ubc},017,BST,7;`;
  console.log("DEBUG: Sending Dali Off Commands:", command1, command2);
  sendRawCommand(command1);
  setTimeout(() => {
    sendRawCommand(command2);
  }, 200);
}

function incrementFittingId() {
  const select = document.getElementById('dali-fitting-id');
  if (select) {
    let idx = select.selectedIndex;
    if (idx < select.options.length - 1) {
      select.selectedIndex = idx + 1;
      console.log("DEBUG: Incremented Fitting ID to:", select.value);
    }
  }
}

function decrementFittingId() {
  const select = document.getElementById('dali-fitting-id');
  if (select) {
    let idx = select.selectedIndex;
    if (idx > 0) {
      select.selectedIndex = idx - 1;
      console.log("DEBUG: Decremented Fitting ID to:", select.value);
    }
  }
}

function toggleDaliFittingEMIdentify() {
  if (daliFittingEMIdentifyInterval === null) {
    const fittingSelect = document.getElementById('dali-fitting-id');
    const fittingVal = fittingSelect ? parseInt(fittingSelect.value, 10) : 0;
    const fittingCmd = "F" + pad(fittingVal, 2);
    const ubc = document.getElementById('dali-ubc') ? document.getElementById('dali-ubc').value : "001";
    const prefix = getUserPrefix();
    const command = `${prefix}$XDALIAPPX2,${ubc},017,${fittingCmd},240,001;`;
    console.log("DEBUG: Starting Fitting EM Identify with command:", command);
    sendRawCommand(command);
    daliFittingEMIdentifyInterval = setInterval(() => {
      sendRawCommand(command);
    }, 5000);
    const btn = document.getElementById('dali-fitting-emidentify-btn');
    if (btn) { btn.textContent = "Stop EM Identify"; }
  } else {
    console.log("DEBUG: Stopping Fitting EM Identify.");
    clearInterval(daliFittingEMIdentifyInterval);
    daliFittingEMIdentifyInterval = null;
    const btn = document.getElementById('dali-fitting-emidentify-btn');
    if (btn) { btn.textContent = "EM Identify"; }
  }
}

function sendDaliFittingFunctionTest() {
  const fittingSelect = document.getElementById('dali-fitting-id');
  const fittingVal = fittingSelect ? parseInt(fittingSelect.value, 10) : 0;
  const fittingCmd = "F" + pad(fittingVal, 2);
  const ubc = document.getElementById('dali-ubc') ? document.getElementById('dali-ubc').value : "001";
  const prefix = getUserPrefix();
  const command = `${prefix}$XDALIAPPX2,${ubc},017,${fittingCmd},227,001;`;
  console.log("DEBUG: Sending Dali Fitting Function Test Command:", command);
  sendRawCommand(command);
}

function toggleDaliFittingFlash() {
  const fittingSelect = document.getElementById('dali-fitting-id');
  const fittingVal = fittingSelect ? parseInt(fittingSelect.value, 10) : 0;
  const fittingCmd = "F" + pad(fittingVal, 2);
  const ubc = document.getElementById('dali-ubc') ? document.getElementById('dali-ubc').value : "001";
  const prefix = getUserPrefix();
  const commandA = `${prefix}$xdali,${ubc},017,${fittingCmd},5;`;
  const commandB = `${prefix}$xdali,${ubc},017,${fittingCmd},6;`;

  if (flashDaliFittingInterval === null) {
    console.log("DEBUG: Starting Flash Dali Fitting. Command A:", commandA);
    sendRawCommand(commandA);
    flashDaliFittingState = true;
    flashDaliFittingInterval = setInterval(() => {
      const cmd = flashDaliFittingState ? commandB : commandA;
      console.log("DEBUG: Sending Flash Dali Fitting command:", cmd);
      sendRawCommand(cmd);
      flashDaliFittingState = !flashDaliFittingState;
    }, 5000);
    const btn = document.getElementById('dali-fitting-flash-btn');
    if (btn) { btn.textContent = "Stop Flash Dali Fitting"; }
  } else {
    console.log("DEBUG: Stopping Flash Dali Fitting.");
    clearInterval(flashDaliFittingInterval);
    flashDaliFittingInterval = null;
    sendRawCommand(commandA);
    const btn = document.getElementById('dali-fitting-flash-btn');
    if (btn) { btn.textContent = "Flash Dali Fitting"; }
  }
}
